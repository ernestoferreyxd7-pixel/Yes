# Scorpy Safio Title Screen (Fabric 1.21.1)

Menú principal animado con tu logo (skull), "by sefixz" abajo a la derecha,
y botones JUGAR / OPCIONES / SALIR.

Animaciones: logo que flota y respira, halo rojo que late, glitch, rayos,
nebulosas a la deriva, estrellas, estrella fugaz y un planeta de bloques
brillantes que gira.

## Compilar
- Local: Java 21 + Gradle 8.10+ y `gradle build`. El jar queda en `build/libs/`.
- Sin PC: sube esta carpeta a un repo de GitHub; en Actions corre "build"
  y descarga el artefacto `scorpysafio-mod`.

## Personalizar
- Logo: reemplaza `src/main/resources/assets/scorpysafio/textures/gui/logo.png`
  (768x768, transparente).
- Fondo propio: PNG de 1920x1080 en `.../textures/gui/background.png`
  (reemplaza al fondo animado generado).
- Textos y colores: `ScorpyTitleScreen.java`.
- Es un mod de cliente: cada jugador debe tenerlo en su carpeta `mods`.
